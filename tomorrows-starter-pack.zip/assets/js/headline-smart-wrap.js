/**
 * headline-smart-wrap.js (hardened)
 * - Inserts at most one <wbr> at a sensible word boundary
 * - Works with nested spans/em/etc via Range across text nodes
 * - Removes any existing <wbr> before applying (idempotent)
 * - Runs once; safe if included more than once
 */
(function(){
  if (window.__headlineSmartWrapSafe__) return;
  window.__headlineSmartWrapSafe__ = true;

  function textLen(node){
    var walker = document.createTreeWalker(node, NodeFilter.SHOW_TEXT);
    var n, total = 0;
    while ((n = walker.nextNode())) total += n.nodeValue.length;
    return total;
  }

  function insertWbrAtOffset(root, absOffset){
    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    var node, remaining = absOffset;
    while ((node = walker.nextNode())) {
      var len = node.nodeValue.length;
      if (remaining <= len) {
        var rng = document.createRange();
        if (remaining <= 0) {
          rng.setStartBefore(node);
        } else if (remaining >= len) {
          rng.setStartAfter(node);
        } else {
          node.splitText(remaining);
          rng.setStartBefore(node.nextSibling);
        }
        rng.collapse(true);
        rng.insertNode(document.createElement('wbr'));
        return true;
      }
      remaining -= len;
    }
    return false;
  }

  function nearestWordBoundary(text, around){
    var left = around, right = around;
    while (left >= 0 || right < text.length){
      if (left >= 0 && /\s/.test(text.charAt(left))) return left;
      if (right < text.length && /\s/.test(text.charAt(right))) return right;
      left--; right++;
    }
    return Math.floor(text.length/2);
  }

  function process(el){
    if (!el || el.dataset.smartWrapApplied === '1') return;
    el.querySelectorAll('wbr').forEach(function(n){ n.remove(); });

    var raw = el.innerText || el.textContent || '';
    var total = raw.length;
    if (total < 10) { el.dataset.smartWrapApplied = '1'; return; }

    var custom = el.getAttribute('data-wbr');
    var offset = custom ? parseInt(custom, 10) : nearestWordBoundary(raw, Math.floor(total/2));
    if (isNaN(offset) || offset <= 0 || offset >= total) { el.dataset.smartWrapApplied = '1'; return; }

    insertWbrAtOffset(el, offset);
    el.dataset.smartWrapApplied = '1';
  }

  function run(){
    document.querySelectorAll('.hero-headline').forEach(process);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run, {once:true});
  } else {
    run();
  }
})();