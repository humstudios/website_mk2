#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""
site_audit_v6.py
Static-site audit with *partials-aware* path resolution.

What it does
------------
1) Missing references (broken local paths) from HTML attributes: src, href, poster, data-include
   - Also picks up <source src>, <link rel="preload">, icons, stylesheets.
   - Skips external (http/https///), mailto:, tel:, data:, javascript:, #
2) Absolute-path usages (should be relative), e.g., "/foo.png", "C:\\..."
3) Orphaned assets: files never referenced by HTML/CSS
   - Parses CSS url(...) to count usage
4) Duplicate HTML IDs (per file)
5) Basic a11y/link issues:
   - <img> without alt (attribute missing)
   - placeholder links: href "#" or empty href

New in v6
---------
• **Partials-aware**: when an HTML file lives in a "partials" directory (or any listed via
  --partials-dirs), references are resolved relative to the *site root* rather than the
  partial file folder. This prevents false "partials/assets/..." missing-path noise.

Usage
-----
  python site_audit_v6.py <root_dir> [--partials-dirs partials includes components]

Examples
--------
  # Basic
  python site_audit_v6.py .

  # Explicitly mark 'partials' as partials dir
  python site_audit_v6.py . --partials-dirs partials

  # Multiple partial-like dirs
  python site_audit_v6.py . --partials-dirs partials includes components
"""
from __future__ import annotations
import os, re, sys
from pathlib import Path
from html.parser import HTMLParser

# ---------------------- Config ----------------------
EXTS_HTML = {".html", ".htm"}
EXTS_CSS  = {".css"}
EXTS_JS   = {".js", ".mjs", ".cjs"}
EXTS_ASSETS = {
    ".png",".jpg",".jpeg",".webp",".svg",".gif",".ico",".avif",
    ".mp4",".webm",".mp3",".wav",".ogg",
    ".woff2",".woff",".ttf",".otf",".eot",
    ".json",".txt",".xml",".pdf"
}
SKIP_PREFIXES = ("http://","https://","//","mailto:","tel:","data:","javascript:","#")
DEFAULT_PARTIAL_DIRS = ("partials","includes","components")

# ---------------------- Args ------------------------
def parse_args(argv):
    root = Path(argv[1] if len(argv) > 1 else ".").resolve()
    partial_dirs = list(DEFAULT_PARTIAL_DIRS)
    if "--partials-dirs" in argv:
        i = argv.index("--partials-dirs")
        given = []
        for val in argv[i+1:]:
            if val.startswith("--"):
                break
            given.append(val.strip("/\\"))
        if given:
            partial_dirs = given
    return root, [d.lower() for d in partial_dirs]

# ---------------------- HTML parser -----------------
class HTMLRefParser(HTMLParser):
    def __init__(self, file_dir: Path):
        super().__init__(convert_charrefs=True)
        self.file_dir = file_dir
        self.refs = []          # list[(attrname, value, tag)]
        self.ids  = []          # list[str]
        self.imgs_missing_alt = 0
        self.placeholder_links = 0

    def handle_starttag(self, tag, attrs):
        attrs_dict = dict(attrs)

        # Collect id attributes for duplicates
        if "id" in attrs_dict:
            self.ids.append(attrs_dict["id"])

        # Placeholder links
        if tag == "a":
            href = attrs_dict.get("href", "")
            if href is not None and href.strip() in ("", "#"):
                self.placeholder_links += 1

        # Img alt check (empty alt "" is allowed for decorative images)
        if tag == "img":
            if "alt" not in attrs_dict:
                self.imgs_missing_alt += 1

        # Refs to verify
        # (We collect here and resolve later, so callers can choose a base dir.)
        for attr in ("src","href","poster","data-include"):
            if attr in attrs_dict:
                val = attrs_dict[attr]
                if val:
                    self.refs.append((attr, val, tag))

# ---------------------- Helpers ---------------------
def normpath(p: str) -> str:
    return p.replace("\\", "/")

def is_external(val: str) -> bool:
    v = val.strip()
    return v.startswith(SKIP_PREFIXES)

def is_absolute_path(val: str) -> bool:
    v = val.strip()
    if v.startswith("//"): return False  # scheme-relative URL, treat as external
    if re.match(r"^[a-zA-Z]:[\\/]", v):  # Windows drive
        return True
    if v.startswith("/") and not re.match(r"^/(?:\*|%|~|#|\?)", v):
        # Leading slash (root-absolute). If your site expects root-relative paths, you may ignore.
        return True
    return False

def resolve_local(ref: str, base_dir: Path) -> Path:
    ref = ref.strip().split("?",1)[0].split("#",1)[0]
    ref = re.sub(r"^\./","",ref)  # remove leading "./"
    return (base_dir / ref).resolve()

def find_html_files(root: Path):
    return sorted([p for p in root.rglob("*") if p.suffix.lower() in EXTS_HTML])

def find_css_files(root: Path):
    return sorted([p for p in root.rglob("*") if p.suffix.lower() in EXTS_CSS])

def find_all_assets(root: Path):
    return sorted([p for p in root.rglob("*") if p.suffix.lower() in EXTS_ASSETS])

def parse_css_urls(css_text: str) -> list[str]:
    urls = re.findall(r"url\(\s*(['\"]?)([^)'\"]+)\1\s*\)", css_text, flags=re.I)
    return [u[1] for u in urls]

# ---------------------- Main ------------------------
def main():
    root, partial_dirs = parse_args(sys.argv)
    if not root.exists():
        print(f"Root not found: {root}", file=sys.stderr)
        sys.exit(2)

    html_files = find_html_files(root)
    css_files  = find_css_files(root)
    all_assets = find_all_assets(root)

    missing = []
    absolutes = []
    refs_used = set()
    dup_ids = {}
    a11y_issues = []  # list of (file, imgs_missing_alt, placeholder_links)

    for html in html_files:
        rel = html.relative_to(root)
        rel_parts_lower = [p.lower() for p in rel.parts]
        # Decide base dir for resolution:
        # If the file lives under a partial-like folder, resolve links relative to *root*,
        # otherwise resolve relative to the HTML file's own directory.
        in_partials_dir = any(part in partial_dirs for part in rel_parts_lower)
        base_dir = root if in_partials_dir else html.parent

        text = html.read_text(encoding="utf-8", errors="ignore")
        parser = HTMLRefParser(html.parent)
        parser.feed(text)

        # duplicate ids
        id_counts = {}
        for i in parser.ids:
            id_counts[i] = id_counts.get(i,0)+1
        file_dups = [i for i,c in id_counts.items() if c>1]
        if file_dups:
            dup_ids[str(rel)] = file_dups

        # record a11y
        if parser.imgs_missing_alt or parser.placeholder_links:
            a11y_issues.append((str(rel), parser.imgs_missing_alt, parser.placeholder_links))

        # check refs
        for attr, val, tag in parser.refs:
            v = val.strip()
            if not v or is_external(v):  # skip externals and empty
                continue
            if is_absolute_path(v):
                absolutes.append((str(rel), v))

            resolved = resolve_local(v, base_dir)
            if not resolved.exists():
                # Only report as missing when it truly doesn't exist from the chosen base
                missing.append((str(rel), str(resolved)))

            # track used refs for orphan check
            try:
                rr = resolved.relative_to(root)
                refs_used.add(normpath(str(rr)))
            except Exception:
                refs_used.add(normpath(str(resolved)))

    # Parse CSS urls
    for css in css_files:
        txt = css.read_text(encoding="utf-8", errors="ignore")
        for url in parse_css_urls(txt):
            if not url or is_external(url) or url.startswith("#") or url.startswith("about:"):
                continue
            res = resolve_local(url, css.parent)
            if res.exists():
                try:
                    rel = res.relative_to(root)
                    refs_used.add(normpath(str(rel)))
                except Exception:
                    refs_used.add(normpath(str(res)))

    # Orphans = assets never referenced
    all_asset_rels = set(normpath(str(p.relative_to(root))) for p in all_assets)
    orphans = sorted(all_asset_rels - refs_used, key=lambda s: (s.split(".")[-1], s.lower()))

    # ---- Output ----
    print("=== Site Audit Summary ===")
    print(f"Root: {root}")
    print(f"HTML files: {len(html_files)}, CSS: {len(css_files)}, JS: {len([p for p in root.rglob('*') if p.suffix.lower() in {'.js','.mjs','.cjs'}])}, Other assets: {len(all_assets)}\\n")

    # 1) Missing
    print("1) Missing references (broken paths):")
    if missing:
        for file, path in missing:
            print(f"  - {file} -> {path} (missing)")
    else:
        print("  ✓ None found")

    # 2) Absolute paths
    print("\\n2) Absolute-path usages (should be relative):")
    if absolutes:
        for file, path in absolutes:
            print(f"  - {file}: {path}")
    else:
        print("  ✓ None found")

    # 3) Orphans – group by ext
    def group_by_ext(paths):
        buckets = {}
        for p in paths:
            ext = "." + p.split(".")[-1].lower() if "." in p else "(noext)"
            buckets.setdefault(ext, []).append(p)
        return buckets
    print("\\n3) Orphaned assets (never referenced):")
    if orphans:
        buckets = group_by_ext(orphans)
        for ext in sorted(buckets.keys()):
            print(f"  {ext} ({len(buckets[ext])}):")
            for p in buckets[ext]:
                print(f"    - {p}")
    else:
        print("  ✓ None")

    # 4) Duplicate ids
    print("\\n4) Duplicate HTML IDs (by file):")
    if dup_ids:
        for file, ids in dup_ids.items():
            print(f"  - {file}: {', '.join(ids)}")
    else:
        print("  ✓ None found")

    # 5) Basic a11y/link issues
    print("\\n5) Basic a11y/link issues:")
    if a11y_issues:
        for file, nimg, nph in a11y_issues:
            if nimg:
                print(f"  - {file}: {nimg} <img> without alt")
            if nph:
                print(f"  - {file}: {nph} placeholder links (href=\"#\" or empty)")
    else:
        print("  ✓ None detected")

    print("\\n6) Candidates to review for removal:")
    print("  (No obvious candidates beyond general orphans above.)")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(130)
