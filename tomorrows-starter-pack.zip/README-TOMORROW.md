# Tomorrow Plan (Safe & Minimal)

## Baseline (5 minutes)
1. Ensure you’re on the **morning build** (the one that “just works”).
2. Confirm `partials/head.html` is the patched one (mask-icon + fonts.css removed).

## Step 1 — Headline crash-proof (drop-in, no visual change)
- Replace: `assets/js/headline-smart-wrap.js` with the one in this pack.
- Why: prevents the Edge `splitText` error; idempotent and safe.
- Test: open **index.html** in Edge/Chrome, ensure no console errors and headline wraps normally.

## Step 2 — Sanity audit (no changes to the site)
- Run from site root:
    ```powershell
    py -3 .\tools\site_audit_v6.py . --partials-dirs partials
    ```
- Expect: no missing refs; no absolute paths; some orphans are fine.

## Step 3 — Optional tiny improvements (only if you want, one at a time)
- A) Fonts-first order: if you ever add image preloads, keep font preloads above them.
- B) OG/Twitter: add on a per-page basis later; no rush.
- C) Intrinsic image sizes: only for images that visibly shift (add width/height).

### Stop criteria
After Step 2, if everything feels good: **stop**. Ship that. Save polish for later.

## Rollback
- If anything feels off, restore the previous `assets/js/headline-smart-wrap.js` from your backup.
- No other files touched by this plan.

---
You’ve already done the hard part: choosing stability. This plan keeps that, and layers in only the smallest, safest wins.