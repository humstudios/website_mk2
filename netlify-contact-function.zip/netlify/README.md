# Hum Studios — Contact Function (Netlify)

This serverless function verifies **reCAPTCHA** and emails contact-form submissions to **info@humstudios.com**.

## Deploy (quick)

1. Push these files to your repo.
2. In **Netlify** → **Site settings** → **Environment variables**, add:
   - `RECAPTCHA_SECRET` — your reCAPTCHA secret key (from Google admin).
   - `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS` — SMTP credentials.
   - `EMAIL_TO` (optional, default is info@humstudios.com)
   - `EMAIL_FROM` (e.g., no-reply@humstudios.com)
3. Click **Deploy**.

## Endpoint

`POST /.netlify/functions/contact`

Accepts either `application/json` or `application/x-www-form-urlencoded`.

### Expected fields
- `name`, `email`, `message`
- `g-recaptcha-response` (from the reCAPTCHA widget)
- `website` (honeypot — leave empty)

## Contact form wiring

Example form (reCAPTCHA v2 checkbox):

```html
<form action="/.netlify/functions/contact" method="POST" class="card" id="contactForm">
  <label>Name <input name="name" required></label>
  <label>Email <input type="email" name="email" required></label>
  <label>Message <textarea name="message" required></textarea></label>

  <!-- Honeypot (hidden) -->
  <div style="position:absolute;left:-10000px;top:auto;width:1px;height:1px;overflow:hidden;">
    <label for="website">Leave this field empty</label>
    <input type="text" id="website" name="website" tabindex="-1" autocomplete="off"/>
  </div>

  <div class="g-recaptcha" data-sitekey="YOUR_SITE_KEY_HERE"></div>
  <button type="submit">Send</button>
</form>

<script src="https://www.google.com/recaptcha/api.js" async defer></script>
```

## Notes

- This function requires Node **18+** (Netlify default is fine).
- If you prefer a provider API (e.g., **SendGrid**, **Resend**), swap the Nodemailer block with their SDK call.
- Lock down CORS: set `allowOrigin` in `functions/contact.js` to your domain, e.g. `https://www.humstudios.com`.
