// functions/contact.js
// Netlify Function: verifies reCAPTCHA and emails form payload to info@humstudios.com
// Env vars required (set in Netlify dashboard):
//   RECAPTCHA_SECRET   -> your reCAPTCHA secret (not the site key)
//   SMTP_HOST          -> e.g., smtp.sendgrid.net
//   SMTP_PORT          -> e.g., 587
//   SMTP_USER          -> SMTP username
//   SMTP_PASS          -> SMTP password
//   EMAIL_TO           -> default: info@humstudios.com (optional override)
//   EMAIL_FROM         -> e.g., no-reply@humstudios.com
//
// Form fields expected:
//   name, email, message, g-recaptcha-response, website (honeypot)
//
// POST /.netlify/functions/contact

import nodemailer from "nodemailer";

const allowOrigin = "*"; // lock this down to your domain if you like

export default async function handler(event, context) {
  // CORS preflight
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 204,
      headers: {
        "Access-Control-Allow-Origin": allowOrigin,
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type"
      },
      body: ""
    };
  }

  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers: { "Access-Control-Allow-Origin": allowOrigin },
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }

  try {
    const contentType = event.headers["content-type"] || event.headers["Content-Type"] || "";
    let data = {};

    if (contentType.includes("application/json")) {
      data = JSON.parse(event.body || "{}");
    } else if (contentType.includes("application/x-www-form-urlencoded")) {
      data = Object.fromEntries(new URLSearchParams(event.body || ""));
    } else {
      // Try JSON by default if unknown
      try { data = JSON.parse(event.body || "{}"); } catch { data = {}; }
    }

    // Honeypot (should be empty)
    if (data.website && String(data.website).trim() !== "") {
      return {
        statusCode: 200,
        headers: { "Access-Control-Allow-Origin": allowOrigin },
        body: JSON.stringify({ ok: true }) // silently accept
      };
    }

    const name = (data.name || "").toString().slice(0, 200);
    const email = (data.email || "").toString().slice(0, 320);
    const message = (data.message || "").toString().slice(0, 5000);
    const token = (data["g-recaptcha-response"] || "").toString();

    if (!name || !email || !message) {
      return {
        statusCode: 400,
        headers: { "Access-Control-Allow-Origin": allowOrigin },
        body: JSON.stringify({ error: "Missing required fields." })
      };
    }

    // Verify reCAPTCHA
    const secret = process.env.RECAPTCHA_SECRET;
    if (!secret) {
      return {
        statusCode: 500,
        headers: { "Access-Control-Allow-Origin": allowOrigin },
        body: JSON.stringify({ error: "Server not configured: missing RECAPTCHA_SECRET" })
      };
    }
    const verifyBody = new URLSearchParams({
      secret,
      response: token,
      remoteip: event.headers["x-forwarded-for"] || ""
    });
    const resp = await fetch("https://www.google.com/recaptcha/api/siteverify", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: verifyBody
    });
    const recaptcha = await resp.json();
    if (!recaptcha.success) {
      return {
        statusCode: 403,
        headers: { "Access-Control-Allow-Origin": allowOrigin },
        body: JSON.stringify({ error: "reCAPTCHA failed", details: recaptcha["error-codes"] || [] })
      };
    }

    // Send mail via SMTP
    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT || 587),
      secure: false,
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS
      }
    });

    const to = process.env.EMAIL_TO || "info@humstudios.com";
    const from = process.env.EMAIL_FROM || "no-reply@humstudios.com";

    const subject = `Hum Studios — Contact form: ${name}`;
    const text = [
      `Name: ${name}`,
      `Email: ${email}`,
      `Message:`,
      message,
      "",
      `UA: ${event.headers["user-agent"] || ""}`
    ].join("\n");

    const html = `
      <h2 style="margin:0 0 12px 0">Hum Studios — Contact form</h2>
      <p><strong>Name:</strong> ${escapeHtml(name)}</p>
      <p><strong>Email:</strong> ${escapeHtml(email)}</p>
      <p><strong>Message:</strong></p>
      <pre style="white-space:pre-wrap;font-family:system-ui,Segoe UI,Roboto,Arial,sans-serif">${escapeHtml(message)}</pre>
      <hr/>
      <p style="font-size:12px;color:#666">UA: ${escapeHtml(event.headers["user-agent"] || "")}</p>
    `;

    await transporter.sendMail({ to, from, subject, text, html });

    return {
      statusCode: 200,
      headers: { "Access-Control-Allow-Origin": allowOrigin },
      body: JSON.stringify({ ok: true })
    };
  } catch (err) {
    return {
      statusCode: 500,
      headers: { "Access-Control-Allow-Origin": allowOrigin },
      body: JSON.stringify({ error: "Server error", detail: String(err) })
    };
  }
}

// Escape HTML to avoid injection in emails
function escapeHtml(str) {
  return String(str)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

// Netlify handler export
export const handler = handler;
